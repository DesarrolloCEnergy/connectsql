<?php
    $hostname = 'transbus-server.database.windows.net';
    $dbname = 'tbg';
    $username = 'transbus-server-admin';
    $password = 'Tr4nsb4s!!.';
    $port = 1433;
    $hosport = $hostname.",".$port;


    // define("hostname","srv-dbtransbus.database.windows.net");
    // define("dbname","tbg");
    // define("username","admindbce");
    // define("password","C4n3l0BD!!.");

?>